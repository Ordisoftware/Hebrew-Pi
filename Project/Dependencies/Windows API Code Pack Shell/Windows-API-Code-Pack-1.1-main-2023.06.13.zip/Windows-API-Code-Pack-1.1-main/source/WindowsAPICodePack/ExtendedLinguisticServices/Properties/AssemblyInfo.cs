﻿// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Runtime.InteropServices;

// Setting ComVisible to false makes the types in this assembly not visible to COM components. If you need to access a type in this assembly
// from COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following _guid is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("938c7476-7ae8-47f9-8c8a-e4e9ea182c23")]